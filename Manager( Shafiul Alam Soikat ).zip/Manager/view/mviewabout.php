<?php
		$title = 'About';
		require_once('mheader.php');
?>
    <section class="contacts">
    <div class="container">
        <Pre>
        <center><h2>SEASON THE MOMENT</h2>
        At Cloud Flame, we believe in everything at its prime. Our focus is to bring the best and most responsibly sourced ingredients to the table.
        
        Cloud Flame is a contemporary Chinese bistro showcasing
        techniques rooted in Bangladesh but influenced by our
        influenced by our regionality, carefully sourcing
        only the best ingredients from both the mid
        atlantic & abroad. Building off the vibrant food
        scene of Paris's Neo-bistro movement, Cloud Flame
        displays an inspiring take on Chinese cuisine in a
        relaxing environment.  This enables our genuine
        approach to food & hospitality to shine.

        Bresca was recognized with one star in the 2019, 
        2020 & 2021 Michelin guides.
</center><pre>
    </div>
    </section>