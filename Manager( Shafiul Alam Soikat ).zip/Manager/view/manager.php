<?php
		$title = 'Manager Home';
		require_once('mheader.php');
?>

    <section class="catagories" style="background-color: #da18a9">
		<div class="container">
			<h2 class="text-center">Welcome To Food Shop</h2>

			<div class="clearfix"></div>
		</div>
	</section>
</body>
</html>