<?php
		$title = 'Contacts';
		require_once('mheader.php');
?>
    <section class="contacts">
    <div class="container">
        <Pre>
        <center><h2>HOURS & LOCATION</h2>
399B Shahid Baki Rd,
Dhaka 1219
+8801876855419
<a href="mail to:admin@cloudflame.com">admin@cloudflame.com</a>
<a href="mail to:employee@cloudflame.com">employee@cloudflame.com</a>

<b>Dine In</b>

Wednesday | Thursday | Sunday : 5.30 - 9.30 PM

Friday & Saturday : 5 - 10 PM

Sunday Lunch : 12.30 - 1.30 PM

Closed Monday & Tuesday

----------------



For additional information or inquires, please email <i> info@cloudflame.com .</i>
</center><pre>
    </div>
    </section>