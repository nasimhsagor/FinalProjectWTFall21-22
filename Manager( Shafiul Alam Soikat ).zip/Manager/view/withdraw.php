<?php
		require_once('mheader.php');   
?>

<section class="contacts">
    <div style="background-color: #bdc91c;" class="container">
        <Pre >
        <center>
        Withdraw Information
            <table >
               
                <tr>
                    <td><img src="n.png" alt="" width="60%"></td>
                    <td><img src="r.png" alt="" width="60%"></td>
                    <td><img src="b.png" alt="" width="60%"></td>
                </tr>
            </table>
</center><pre>
    </div>
    </section>