-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2021 at 02:40 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(70) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `type` text NOT NULL,
  `dob` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `gender` text NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`name`, `username`, `password`, `email`, `address`, `phone`, `type`, `dob`, `gender`, `image`) VALUES
('Nasim Haidar Sagor', 'sagor', 'Sagor@1122', 'nasimhaidarsagor@gmail.com', '7/J/2 West Hazipara, Rampura, Dhaka-1219', '01746330309', 'User', '1998-08-23 18:00:00', 'Male', 0x70726f7069332e6a7067),
('Rimon Nath', 'rimon', 'rimon@1122', 'rimon@gmail.com', 'Kuratoli', '01833030946', 'User', '1999-12-04 18:00:00', 'Male', 0x53637265656e73686f7420323032312d31312d3134203232313730362e706e67),
('Mahedi Hasan', 'munna', 'munna@1122', 'munnagalaxys7@gmail.com', 'Gazipur', '01785342543', 'User', '1999-12-29 18:00:00', 'Male', 0x466f6f645f7069635f3232372e6a7067),
('adnan faruk', 'faruk', '@12345678', 'faruk.adnan1998@gmail.com', 'bashundhora,dhaka', '01632840649', 'User', '1999-11-30 18:00:00', 'Male', 0x312e6a7067);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
