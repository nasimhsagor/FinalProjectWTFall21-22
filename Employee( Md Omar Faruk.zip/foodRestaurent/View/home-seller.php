<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <title>Restaurent Management System.com</title>

   <?php include_once 'header.php' ?>

</head>

<body>
   <h3 style="color: red; background-color: beige;" align="center">Home</h3>
   <!--nav sec strt here--> 
   <div class="nav">
      <div class="wraper">
         <div class="nav-bar">
            <ul>
               <li><a href="#">Home</a></li>
               <li><a href="./products.php">Menu</a></li>
               <li><a href="./addProduct.php">Add Menu</a></li>
               <li><a href="./orderProduct.php">Ordered Menu</</a></li>
                
               <li><a href="./contact-us.php">Contact us</a></li>
             <!--  <li><a href="#">Phone</a></li>
               <li><a href="#">Order</a></li>
            --></ul>
         </div>
      </div>
   </div>
   <!--nav sec end here--> 


   <?php include_once 'footer.php' ?>
   


</body>
</html>