
<!DOCTYPE html>
<html>
  <body>

    <!-- [SEARCH FORM] -->
    <form method="post" action="../Controller/findProduct.php">
      <h1>SEARCH FOR MENU</h1>
     
       <input type="text"  placeholder="Find Menu.."name="product_name" />

      <input type="submit" name="findProduct" value="Search"/>
    </form>


 
  </body>
</html>