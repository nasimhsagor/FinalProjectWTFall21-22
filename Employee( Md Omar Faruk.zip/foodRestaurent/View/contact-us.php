<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
  <?php include_once 'header.php' ?>
</head>

<body>
 <div>
 	   <h3 style="color: red; background-color: beige;" align="center">Contact Us</h3>
 </div>

 <table>
  
  <tr>
    <td>Title</td>
    <td>Details</td>
   
  </tr>
  <tr>
    <td>Name</td>
    <td>Restaurent Management System</td>

  </tr>
  <tr>
    <td>Number</td>
    <td>+8801787092919</td>

  </tr>
  <tr>
    <td>E-mail</td>
    <td>restaurent720@gmail.com</td>

  </tr>
  <tr>
    <td>Address</td>
    <td>6/18 Road, Uttara, Dhaka</td>

  </tr>
</table>

  <?php include_once 'footer.php' ?>

</body>
</html>