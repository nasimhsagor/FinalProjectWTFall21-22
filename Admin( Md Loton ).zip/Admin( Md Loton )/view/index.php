<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Acces Denied</title>
	<link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">

</head>
<body>
	<div class="header"><h2 class="glyphicon glyphicon-"> AB Star Restaurant </h2></strong></div>
	<!-- <p><a href="../view/home-page.php" class="btn">Back to Home</a><p> -->
	<br><br><br><br>
	<table align="center">
		<tr>
			<td><span class="welcome"><strong>You are not allow to access this Directory</strong></span></td>
		</tr>
	</table>
 <?php include '../view/footer.php' ; ?>

</body>
</html>