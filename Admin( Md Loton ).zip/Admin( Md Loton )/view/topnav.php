<div class="topnav">
    <div class="topnav-right">
        <span class="topnav-log-identity">Welcome, <a href="../view/profile.php"><?php echo $user; ?></a></span>
        <span class="c2"><a href="../control/logout.php">Logout</a></span> 
    </div>
</div>